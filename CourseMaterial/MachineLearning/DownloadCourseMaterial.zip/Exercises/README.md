These exercises are forked from [Gerges Dib](https://github.com/dibgerge/ml-coursera-python-assignments)

To solve the exercises, download the [zip file](CourseMaterial/MachineLearning/Exercises/AllExercisesForDownload.zip) containing all Jupyter Notebooks. Then unpack the zipfile, launch Jupyter Notebook through Anaconda, and begin implementing your solutions. 

NOTE: The submission and grading cells in the exercises should be ignored (they are only for students obtaining a certificate from Coursera)
