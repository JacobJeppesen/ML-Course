These lecture notes are forked from [Remy Marquis](https://github.com/rmarquis/coursera-machinelearning)

Other review notes are available at:
* http://www.holehouse.org/mlclass/
